LOCAL_PATH := $(call my-dir)

# ----------------------------------------------------------------
# Stage 1: Force Compile Google Oboe statically (Cloud Ready)
# ----------------------------------------------------------------
include $(CLEAR_VARS)

LOCAL_MODULE := oboe_static

# 🔥 AAUDIO IS BACK! Cloud compiler isko perfectly compile karega 🔥
MY_OBOE_SRCS := $(wildcard $(LOCAL_PATH)/oboe/src/common/*.cpp)
MY_OBOE_SRCS += $(wildcard $(LOCAL_PATH)/oboe/src/aaudio/*.cpp)
MY_OBOE_SRCS += $(wildcard $(LOCAL_PATH)/oboe/src/fifo/*.cpp)
MY_OBOE_SRCS += $(wildcard $(LOCAL_PATH)/oboe/src/flowgraph/*.cpp)
MY_OBOE_SRCS += $(wildcard $(LOCAL_PATH)/oboe/src/opensles/*.cpp)

LOCAL_SRC_FILES := $(MY_OBOE_SRCS:$(LOCAL_PATH)/%=%)

LOCAL_C_INCLUDES := $(LOCAL_PATH)/oboe $(LOCAL_PATH)/oboe/src

# Yahan se -DOBOE_ENABLE_AAUDIO=0 hata diya gaya hai
LOCAL_CFLAGS := -O3 -std=c++17 -march=armv8-a -mfpu=neon -mfloat-abi=softfp -fexceptions -frtti

include $(BUILD_STATIC_LIBRARY)


# ----------------------------------------------------------------
# Stage 2: Link your custom EliteAudioEngine to the static Oboe build
# ----------------------------------------------------------------
include $(CLEAR_VARS)

LOCAL_MODULE    := elite_audio_engine
LOCAL_SRC_FILES := EliteAudioEngine.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/oboe $(LOCAL_PATH)/oboe/src

LOCAL_LDLIBS := -lOpenSLES -llog -landroid

LOCAL_STATIC_LIBRARIES := oboe_static

# Yahan se bhi AAudio disable karne wala switch hata diya gaya hai
LOCAL_CFLAGS := -O3 -std=c++17 -march=armv8-a -mfpu=neon -mfloat-abi=softfp

include $(BUILD_SHARED_LIBRARY)
