#include <jni.h>
#include <cmath>
#include <atomic>
#include <vector>
#include <arm_neon.h>
#include <Oboe.h> // Force compiled header path link

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

struct VectorFilter {
    float32x4_t b0, b1, b2, a1, a2;
    float32x4_t x1, x2, y1, y2;

    void reset() {
        x1 = vdupq_n_f32(0.0f); x2 = vdupq_n_f32(0.0f);
        y1 = vdupq_n_f32(0.0f); y2 = vdupq_n_f32(0.0f);
    }

    void calculatePeakingEQ(float frequency, float sampleRate, float gainDb, float Q) {
        float A = std::pow(10.0f, gainDb / 40.0f);
        float omega = 2.0f * (float)M_PI * frequency / sampleRate;
        float alpha = std::sin(omega) / (2.0f * Q);
        float cosOmega = std::cos(omega);

        float norm = 1.0f + alpha / A;
        b0 = vdupq_n_f32((1.0f + alpha * A) / norm);
        b1 = vdupq_n_f32((-2.0f * cosOmega) / norm);
        b2 = vdupq_n_f32((1.0f - alpha * A) / norm);
        a1 = vdupq_n_f32((-2.0f * cosOmega) / norm);
        a2 = vdupq_n_f32((1.0f - alpha / A) / norm);
    }
};

class EliteAudioProcessor {
private:
    std::vector<VectorFilter> filterBands;
    std::atomic<float> currentGain{1.0f};
    
    const float safety_ceiling = 0.45f;   
    const float footstep_floor = 0.05f;   
    const float attack = 0.001f;          
    const float release = 0.995f;         

public:
    EliteAudioProcessor() {
        filterBands.resize(10);
        float frequencies[10] = {60.f, 150.f, 400.f, 1000.f, 2500.f, 4000.f, 6000.f, 8000.f, 10000.f, 12000.f};
        float defaultGains[10] = {-6.0f, -6.0f, 3.5f, 3.5f, 7.0f, 7.0f, -4.0f, -4.0f, -4.0f, -4.0f};
        
        for (int i = 0; i < 10; ++i) {
            filterBands[i].reset();
            filterBands[i].calculatePeakingEQ(frequencies[i], 48000.0f, defaultGains[i], 1.0f);
        }
    }

    void setBandGain(int index, float gainDb) {
        if (index >= 0 && index < 10) {
            float frequencies[10] = {60.f, 150.f, 400.f, 1000.f, 2500.f, 4000.f, 6000.f, 8000.f, 10000.f, 12000.f};
            filterBands[index].calculatePeakingEQ(frequencies[index], 48000.0f, gainDb, 1.0f);
        }
    }

    void processAudioSIMD(float* buffer, int totalSamples) {
        int i = 0;
        for (; i <= totalSamples - 4; i += 4) {
            float32x4_t data_vec = vld1q_f32(&buffer[i]);

            for (auto& filter : filterBands) {
                float32x4_t feedForward = vmulq_f32(data_vec, filter.b0);
                feedForward = vmlaq_f32(feedForward, filter.x1, filter.b1);
                feedForward = vmlaq_f32(feedForward, filter.x2, filter.b2);

                float32x4_t feedback = vmulq_f32(filter.y1, filter.a1);
                feedback = vmlaq_f32(feedback, filter.y2, filter.a2);

                float32x4_t out_vec = vsubq_f32(feedForward, feedback);

                filter.x2 = filter.x1; filter.x1 = data_vec;
                filter.y2 = filter.y1; filter.y1 = out_vec;

                data_vec = out_vec;
            }

            float32x4_t abs_data = vabsq_f32(data_vec);
            float max_peak = vgetq_lane_f32(abs_data, 0);
            for(int j = 1; j < 4; ++j) {
                float lane_val = (j == 1) ? vgetq_lane_f32(abs_data, 1) : 
                                 ((j == 2) ? vgetq_lane_f32(abs_data, 2) : vgetq_lane_f32(abs_data, 3));
                if (lane_val > max_peak) max_peak = lane_val;
            }

            float targetGain = 1.0f;
            if (max_peak > safety_ceiling) {
                targetGain = safety_ceiling / (max_peak + 0.00001f);
                currentGain.store(currentGain.load() * attack + targetGain * (1.0f - attack));
            } else if (max_peak < footstep_floor && max_peak > 0.001f) {
                targetGain = 2.5f;
                currentGain.store(currentGain.load() * (1.0f - release) + targetGain * release);
            } else {
                currentGain.store(currentGain.load() * 0.99f + 1.0f * 0.01f);
            }

            float32x4_t v_smart_gain = vdupq_n_f32(currentGain.load());
            data_vec = vmulq_f32(data_vec, v_smart_gain);
            vst1q_f32(&buffer[i], data_vec);
        }

        for (; i < totalSamples; ++i) {
            float sample = buffer[i];
            for (auto& filter : filterBands) {
                float out = vgetq_lane_f32(filter.b0, 0) * sample 
                          + vgetq_lane_f32(filter.b1, 0) * vgetq_lane_f32(filter.x1, 0) 
                          + vgetq_lane_f32(filter.b2, 0) * vgetq_lane_f32(filter.x2, 0) 
                          - vgetq_lane_f32(filter.a1, 0) * vgetq_lane_f32(filter.y1, 0) 
                          - vgetq_lane_f32(filter.a2, 0) * vgetq_lane_f32(filter.y2, 0);
                
                float32x4_t next_x = vdupq_n_f32(sample); float32x4_t next_y = vdupq_n_f32(out);
                filter.x2 = filter.x1; filter.x1 = next_x; filter.y2 = filter.y1; filter.y1 = next_y;
                sample = out;
            }
            buffer[i] = sample * currentGain.load();
        }
    }
};

// --- GOOGLE OBOE COMPLIANT ENGINE HOOKS ---
class OboeAudioStreamEngine : public oboe::AudioStreamDataCallback {
private:
    std::shared_ptr<oboe::AudioStream> mStream;
    EliteAudioProcessor* mProcessor;

public:
    OboeAudioStreamEngine(EliteAudioProcessor* processor) : mProcessor(processor) {}

    bool start() {
        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Output)
               ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
               ->setSharingMode(oboe::SharingMode::Exclusive)
               ->setFormat(oboe::AudioFormat::Float)
               ->setChannelCount(oboe::ChannelCount::Stereo)
               ->setSampleRate(48000)
               ->setDataCallback(this);

        oboe::Result result = builder.openStream(mStream);
        if (result != oboe::Result::OK) return false;

        result = mStream->requestStart();
        return result == oboe::Result::OK;
    }

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream *audioStream, void *audioData, int32_t numFrames) override {
        auto *floatData = static_cast<float *>(audioData);
        int totalSamples = numFrames * audioStream->getChannelCount();
        
        if (mProcessor != nullptr) {
            mProcessor->processAudioSIMD(floatData, totalSamples);
        }
        return oboe::DataCallbackResult::Continue;
    }

    void stop() {
        if (mStream) {
            mStream->requestStop();
            mStream->close();
        }
    }
};

extern "C" {
    struct EngineContainer {
        EliteAudioProcessor* processor;
        OboeAudioStreamEngine* streamEngine;
    };

    JNIEXPORT jlong JNICALL Java_com_audio_sound_master_PremiumAudioService_initNativeEngine(JNIEnv* env, jobject thiz) {
        auto* container = new EngineContainer();
        container->processor = new EliteAudioProcessor();
        container->streamEngine = new OboeAudioStreamEngine(container->processor);
        container->streamEngine->start(); 
        return reinterpret_cast<jlong>(container);
    }

    JNIEXPORT void JNICALL Java_com_audio_sound_master_PremiumAudioService_setNativeBandGain(JNIEnv* env, jobject thiz, jlong handle, jint band, jfloat gain) {
        auto* container = reinterpret_cast<EngineContainer*>(handle);
        if (container && container->processor) container->processor->setBandGain(band, gain);
    }
    
    JNIEXPORT void JNICALL Java_com_audio_sound_master_PremiumAudioService_releaseNativeEngine(JNIEnv* env, jobject thiz, jlong handle) {
        auto* container = reinterpret_cast<EngineContainer*>(handle);
        if (container) {
            if (container->streamEngine) {
                container->streamEngine->stop();
                delete container->streamEngine;
            }
            if (container->processor) delete container->processor;
            delete container;
        }
    }
}
