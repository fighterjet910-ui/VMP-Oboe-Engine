package com.audio.sound.master;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class PremiumAudioService extends Service {

    private static PremiumAudioService instance;
    private long nativeProcessorHandle = 0; 
    private FloatingMenuWindow uiWindow;
    private SharedPreferences memoryMatrix;
    private static final String CHANNEL_ID = "vmp_warp_speed_core";

    private native long initNativeEngine();
    private native void setNativeBandGain(long handle, int band, float gain);
    private native void processNativeSamples(long handle, float[] samples, int size);
    private native void releaseNativeEngine(long handle);

    private final BroadcastReceiver actionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if ("SHOW_VMP_UI".equals(action) && uiWindow != null) {
                uiWindow.showIcon();
            } else if ("STOP_VMP_ENGINE".equals(action)) {
                if (uiWindow != null) uiWindow.hideUI();
                stopSelf(); 
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        memoryMatrix = getSharedPreferences("VMP_CONFIGS", MODE_PRIVATE);
        
        IntentFilter filter = new IntentFilter();
        filter.addAction("SHOW_VMP_UI");
        filter.addAction("STOP_VMP_ENGINE");
        
        // ✅ ANDROID 16 COMPATIBILITY BUGFIX: Explicitly handle dynamic receiver export rules
        if (Build.VERSION.SDK_INT >= 34) { // Build.VERSION_CODES.UPSIDE_DOWN_CAKE
            registerReceiver(actionReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(actionReceiver, filter);
        }
        
        // SAFE LIBRARY LOADING INSIDE TRY-CATCH
        try {
            System.loadLibrary("elite_audio_engine");
            lockServiceToForegroundMemory();
            nativeProcessorHandle = initNativeEngine();
            showToast("SIMD OpenSL Engine Engaged!");
        } catch (Throwable t) {
            showToast("FATAL ERROR (C++ Missing): " + t.getMessage());
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this)) uiWindow = new FloatingMenuWindow(this);
            } else {
                uiWindow = new FloatingMenuWindow(this);
            }
        } catch (Throwable t) {
            showToast("UI Error: " + t.getMessage());
        }
    }

    private void showToast(final String message) {
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(PremiumAudioService.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void lockServiceToForegroundMemory() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "VMP Hardware", NotificationManager.IMPORTANCE_LOW);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }

        Intent showIntent = new Intent("SHOW_VMP_UI");
        PendingIntent pShow = PendingIntent.getBroadcast(this, 0, showIntent, PendingIntent.FLAG_IMMUTABLE);
        Intent stopIntent = new Intent("STOP_VMP_ENGINE");
        PendingIntent pStop = PendingIntent.getBroadcast(this, 1, stopIntent, PendingIntent.FLAG_IMMUTABLE);
        
        Notification notification = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) 
            ? new Notification.Builder(this, CHANNEL_ID).setContentTitle("AIDE Pro Audio Engine").setContentIntent(pShow).setSmallIcon(android.R.drawable.ic_media_play).addAction(android.R.drawable.ic_menu_close_clear_cancel, "STOP", pStop).build()
            : new Notification.Builder(this).setContentTitle("AIDE Pro Audio Engine").setContentIntent(pShow).setSmallIcon(android.R.drawable.ic_media_play).build();

        if (Build.VERSION.SDK_INT >= 29) { // Build.VERSION_CODES.Q
            startForeground(202, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(202, notification);
        }
    }

    public static void updateBand(int bandIndex, float gainValue) {
        if (instance != null && instance.nativeProcessorHandle != 0) {
            instance.setNativeBandGain(instance.nativeProcessorHandle, bandIndex, gainValue);
        }
    }
    
    public static void updateSpatialAwareness(int strengthValue) {}

    public static void loadConfiguration(String configName) {
        if (instance != null) {
            for(int i=0; i<10; i++) {
                float savedGain = instance.memoryMatrix.getFloat(configName + "_band_" + i, 0f);
                updateBand(i, savedGain);
                VMP_ControllerView.currentBands[i] = savedGain; 
            }
        }
    }

    public static void saveConfiguration(String name, float[] bands, int spatial) {
        if (instance != null) {
            SharedPreferences.Editor editor = instance.memoryMatrix.edit();
            for(int i=0; i<10; i++) editor.putFloat(name + "_band_" + i, bands[i]);
            editor.apply();
        }
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        // ✅ ROBUST RESOURCE UNLINKING: Wraps unregister routine to protect against lifecycle leaks
        try {
            unregisterReceiver(actionReceiver);
        } catch (IllegalArgumentException e) {
            // Context mapping already safely clean or unlinked from the kernel
        }
        
        if (nativeProcessorHandle != 0) {
            releaseNativeEngine(nativeProcessorHandle);
            nativeProcessorHandle = 0;
        }
        instance = null;
        super.onDestroy();
    }
}
